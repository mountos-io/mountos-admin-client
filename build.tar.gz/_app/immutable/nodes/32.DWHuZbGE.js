import{_ as m}from"../chunks/BTS-XOMC.js";export{m as component};
