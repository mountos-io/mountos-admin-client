import{_ as m}from"../chunks/CsdsToGC.js";export{m as component};
