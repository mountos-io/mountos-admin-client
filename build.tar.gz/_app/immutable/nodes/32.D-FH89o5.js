import{_ as m}from"../chunks/CUIc4qPN.js";export{m as component};
