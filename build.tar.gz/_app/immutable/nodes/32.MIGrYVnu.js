import{_ as m}from"../chunks/DVqr-AWx.js";export{m as component};
