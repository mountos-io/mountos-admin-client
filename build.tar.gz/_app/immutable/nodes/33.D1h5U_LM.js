import{_ as m}from"../chunks/BcB2VDbL.js";export{m as component};
