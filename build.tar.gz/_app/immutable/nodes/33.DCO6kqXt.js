import{_ as m}from"../chunks/BBUJ8pf9.js";export{m as component};
