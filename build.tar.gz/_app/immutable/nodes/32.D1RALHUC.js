import{_ as m}from"../chunks/B5DKYxmC.js";export{m as component};
