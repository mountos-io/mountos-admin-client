import{_ as m}from"../chunks/DcgjoN1O.js";export{m as component};
