import{_ as m}from"../chunks/B4MmkWa_.js";export{m as component};
