import{_ as m}from"../chunks/aLzmjYo8.js";export{m as component};
