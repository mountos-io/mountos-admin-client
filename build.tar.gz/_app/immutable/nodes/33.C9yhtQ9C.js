import{_ as m}from"../chunks/RnTqLa-n.js";export{m as component};
