import{_ as m}from"../chunks/nOd6yfyl.js";export{m as component};
