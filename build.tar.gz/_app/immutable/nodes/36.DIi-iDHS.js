import{_ as m}from"../chunks/BTKxdMQC.js";export{m as component};
