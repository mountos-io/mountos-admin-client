import{_ as m}from"../chunks/DAt7DSj1.js";export{m as component};
