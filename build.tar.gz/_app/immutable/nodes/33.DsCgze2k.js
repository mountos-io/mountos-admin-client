import{_ as m}from"../chunks/D8Ui5192.js";export{m as component};
