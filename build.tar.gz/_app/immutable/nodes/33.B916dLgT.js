import{_ as m}from"../chunks/DfKjXcmv.js";export{m as component};
