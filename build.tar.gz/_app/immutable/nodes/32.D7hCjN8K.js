import{_ as m}from"../chunks/DStA-FIZ.js";export{m as component};
