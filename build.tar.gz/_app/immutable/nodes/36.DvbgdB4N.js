import{_ as m}from"../chunks/Dy8ODJIu.js";export{m as component};
