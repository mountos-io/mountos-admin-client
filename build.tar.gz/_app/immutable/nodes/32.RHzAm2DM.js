import{_ as m}from"../chunks/8H0SMkhR.js";export{m as component};
