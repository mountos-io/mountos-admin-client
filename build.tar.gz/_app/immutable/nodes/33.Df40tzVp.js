import{_ as m}from"../chunks/BjJw9Dcw.js";export{m as component};
