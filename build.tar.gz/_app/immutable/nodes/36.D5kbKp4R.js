import{_ as m}from"../chunks/DH10kgHw.js";export{m as component};
