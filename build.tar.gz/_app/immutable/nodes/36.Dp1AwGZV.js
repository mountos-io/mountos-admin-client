import{_ as m}from"../chunks/DRJQz_s0.js";export{m as component};
