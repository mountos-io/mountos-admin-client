import{_ as m}from"../chunks/D-NwjyXg.js";export{m as component};
