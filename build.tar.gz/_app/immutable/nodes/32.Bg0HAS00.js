import{_ as m}from"../chunks/BBklyY_E.js";export{m as component};
