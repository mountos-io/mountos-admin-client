import{_ as m}from"../chunks/CGF8eIHh.js";export{m as component};
