import{_ as m}from"../chunks/C4uVxdIC.js";export{m as component};
