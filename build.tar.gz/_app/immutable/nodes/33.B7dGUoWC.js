import{_ as m}from"../chunks/CKM5GQQ7.js";export{m as component};
