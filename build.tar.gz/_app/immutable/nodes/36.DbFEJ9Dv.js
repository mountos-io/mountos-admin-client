import{_ as m}from"../chunks/CLpoFxa_.js";export{m as component};
