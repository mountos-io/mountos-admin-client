import{_ as m}from"../chunks/DCLvXVdA.js";export{m as component};
