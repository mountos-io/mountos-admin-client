import{_ as m}from"../chunks/p2cnBHfu.js";export{m as component};
