import{_ as m}from"../chunks/5oNc1x0y.js";export{m as component};
