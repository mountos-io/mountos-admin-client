import{_ as m}from"../chunks/BdNbwflI.js";export{m as component};
