import{_ as m}from"../chunks/DoA8w6vo.js";export{m as component};
