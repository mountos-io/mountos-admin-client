import{_ as m}from"../chunks/BNzhi5k7.js";export{m as component};
