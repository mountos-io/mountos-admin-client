import{_ as m}from"../chunks/DhRXZRcU.js";export{m as component};
