import{_ as m}from"../chunks/xRcCU18N.js";export{m as component};
