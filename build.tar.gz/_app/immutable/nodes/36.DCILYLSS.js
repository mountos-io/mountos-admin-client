import{_ as m}from"../chunks/BQiUbKDU.js";export{m as component};
