import{_ as m}from"../chunks/DTwmEYJN.js";export{m as component};
