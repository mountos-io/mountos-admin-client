import{_ as m}from"../chunks/liqnnLB6.js";export{m as component};
