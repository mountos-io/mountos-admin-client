import{_ as m}from"../chunks/DTxgkz2F.js";export{m as component};
