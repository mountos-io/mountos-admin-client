import{_ as m}from"../chunks/BOgRYjmV.js";export{m as component};
