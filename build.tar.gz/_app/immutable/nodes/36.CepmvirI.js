import{_ as m}from"../chunks/BV4jJ6ho.js";export{m as component};
