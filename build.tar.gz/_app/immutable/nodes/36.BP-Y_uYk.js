import{_ as m}from"../chunks/BVgC9-iz.js";export{m as component};
