import{_ as m}from"../chunks/CgnxuMhe.js";export{m as component};
