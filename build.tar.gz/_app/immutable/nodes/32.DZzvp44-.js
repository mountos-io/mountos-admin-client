import{_ as m}from"../chunks/IvZTDX2d.js";export{m as component};
