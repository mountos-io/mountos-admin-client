import{_ as m}from"../chunks/CMfJxTzC.js";export{m as component};
