import{_ as m}from"../chunks/C17r6O4P.js";export{m as component};
