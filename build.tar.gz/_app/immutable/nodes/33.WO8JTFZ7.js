import{_ as m}from"../chunks/ClCKXPmL.js";export{m as component};
