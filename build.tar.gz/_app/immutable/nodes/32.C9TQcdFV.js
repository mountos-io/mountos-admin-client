import{_ as m}from"../chunks/BDpZF1Sa.js";export{m as component};
