import{_ as m}from"../chunks/D30-hBsO.js";export{m as component};
