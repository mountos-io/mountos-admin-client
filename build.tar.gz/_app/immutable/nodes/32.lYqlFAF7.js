import{_ as m}from"../chunks/blCHXOCa.js";export{m as component};
