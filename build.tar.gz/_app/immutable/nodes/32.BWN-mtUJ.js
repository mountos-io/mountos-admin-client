import{_ as m}from"../chunks/hX5PM6Mh.js";export{m as component};
