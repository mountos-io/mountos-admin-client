import{_ as m}from"../chunks/-RjOMIkG.js";export{m as component};
