import{_ as m}from"../chunks/COgQa55P.js";export{m as component};
