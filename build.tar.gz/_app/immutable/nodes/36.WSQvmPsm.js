import{_ as m}from"../chunks/Cck3jIHC.js";export{m as component};
