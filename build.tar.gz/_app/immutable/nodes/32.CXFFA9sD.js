import{_ as m}from"../chunks/iX1VMnY2.js";export{m as component};
