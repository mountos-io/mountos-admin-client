import{_ as m}from"../chunks/UZ0EATu2.js";export{m as component};
