import{_ as m}from"../chunks/e68rDMN7.js";export{m as component};
