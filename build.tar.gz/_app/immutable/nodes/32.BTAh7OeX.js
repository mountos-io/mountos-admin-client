import{_ as m}from"../chunks/Cf5gwTMF.js";export{m as component};
