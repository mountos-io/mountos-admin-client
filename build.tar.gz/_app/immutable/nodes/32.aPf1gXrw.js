import{_ as m}from"../chunks/DK7uLW7v.js";export{m as component};
