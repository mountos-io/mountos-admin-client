import{_ as m}from"../chunks/BZq7mQ18.js";export{m as component};
