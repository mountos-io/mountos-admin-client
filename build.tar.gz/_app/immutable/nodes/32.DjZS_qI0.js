import{_ as m}from"../chunks/CQD-y5Cc.js";export{m as component};
