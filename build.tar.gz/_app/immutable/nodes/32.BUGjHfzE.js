import{_ as m}from"../chunks/BYSgCOg_.js";export{m as component};
