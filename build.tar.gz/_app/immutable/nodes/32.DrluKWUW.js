import{_ as m}from"../chunks/oR8GhV3H.js";export{m as component};
