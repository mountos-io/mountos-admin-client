import{_ as m}from"../chunks/BpY9Pqip.js";export{m as component};
