import{_ as m}from"../chunks/DbVaCObJ.js";export{m as component};
