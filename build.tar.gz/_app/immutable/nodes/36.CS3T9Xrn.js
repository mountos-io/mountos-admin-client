import{_ as m}from"../chunks/CfkK6ErU.js";export{m as component};
