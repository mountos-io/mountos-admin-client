import{_ as m}from"../chunks/C29Lt3w_.js";export{m as component};
