import{_ as m}from"../chunks/C6DMYhdr.js";export{m as component};
