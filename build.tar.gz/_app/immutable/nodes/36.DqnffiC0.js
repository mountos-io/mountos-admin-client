import{_ as m}from"../chunks/B9Bp29JB.js";export{m as component};
