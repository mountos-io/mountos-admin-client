import{_ as m}from"../chunks/DycpFuoE.js";export{m as component};
