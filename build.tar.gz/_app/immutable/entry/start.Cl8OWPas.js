import{a as r}from"../chunks/CNY7nf6y.js";import{x as t}from"../chunks/DmA0EClD.js";export{t as load_css,r as start};
