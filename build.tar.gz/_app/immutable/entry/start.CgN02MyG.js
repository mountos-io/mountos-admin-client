import{a as r}from"../chunks/Czvadaj_.js";import{x as t}from"../chunks/sM_jglTq.js";export{t as load_css,r as start};
