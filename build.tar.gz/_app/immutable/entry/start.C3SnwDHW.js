import{a as r}from"../chunks/BxjOAJdq.js";import{x as t}from"../chunks/BcjrIUFJ.js";export{t as load_css,r as start};
