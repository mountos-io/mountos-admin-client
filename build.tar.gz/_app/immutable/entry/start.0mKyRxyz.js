import{l as o,a as r}from"../chunks/K3o4UgXC.js";export{o as load_css,r as start};
