import{l as o,a as r}from"../chunks/Dnhsg0fD.js";export{o as load_css,r as start};
