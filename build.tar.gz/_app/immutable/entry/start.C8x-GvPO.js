import{a as r}from"../chunks/CtooCSXT.js";import{x as t}from"../chunks/B9MWttnp.js";export{t as load_css,r as start};
