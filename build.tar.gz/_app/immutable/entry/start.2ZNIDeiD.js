import{a as r}from"../chunks/Cb4FV3qa.js";import{x as t}from"../chunks/DlbL8NqU.js";export{t as load_css,r as start};
