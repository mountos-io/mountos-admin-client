import{a as r}from"../chunks/BOi6U7dY.js";import{x as t}from"../chunks/iXt6Z3WT.js";export{t as load_css,r as start};
