import{a as r}from"../chunks/CM8Tx08M.js";import{x as t}from"../chunks/CgI1Q8rE.js";export{t as load_css,r as start};
