import{l as o,a as r}from"../chunks/CGZV86p1.js";export{o as load_css,r as start};
