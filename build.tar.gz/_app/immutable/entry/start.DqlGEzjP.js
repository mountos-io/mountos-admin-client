import{a as r}from"../chunks/B9T7P4hA.js";import{x as t}from"../chunks/BsKq1OyW.js";export{t as load_css,r as start};
