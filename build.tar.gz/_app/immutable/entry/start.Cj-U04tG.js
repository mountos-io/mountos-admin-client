import{a as r}from"../chunks/39c7hfBQ.js";import{x as t}from"../chunks/CI_NCJKh.js";export{t as load_css,r as start};
