import{a as r}from"../chunks/CnGIhgEZ.js";import{x as t}from"../chunks/BOOD6Hrr.js";export{t as load_css,r as start};
