import{l as o,a as r}from"../chunks/BDsp3MKg.js";export{o as load_css,r as start};
