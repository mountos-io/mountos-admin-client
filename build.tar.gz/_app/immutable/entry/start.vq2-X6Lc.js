import{a as r}from"../chunks/C6eNwAIs.js";import{x as t}from"../chunks/DfJ1uBdJ.js";export{t as load_css,r as start};
