import{a as r}from"../chunks/Dfp-JHhz.js";import{x as t}from"../chunks/3sIqfRZ9.js";export{t as load_css,r as start};
