import{a as r}from"../chunks/DaKHSpE5.js";import{x as t}from"../chunks/Ca_SlYyD.js";export{t as load_css,r as start};
