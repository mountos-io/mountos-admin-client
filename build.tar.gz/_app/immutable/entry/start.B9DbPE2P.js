import{a as r}from"../chunks/Y5Bmu7-3.js";import{x as t}from"../chunks/BrPWLrrn.js";export{t as load_css,r as start};
