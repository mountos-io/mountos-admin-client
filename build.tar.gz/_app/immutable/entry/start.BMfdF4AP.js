import{a as r}from"../chunks/6Ic-fD-q.js";import{x as t}from"../chunks/mGUHaY7J.js";export{t as load_css,r as start};
