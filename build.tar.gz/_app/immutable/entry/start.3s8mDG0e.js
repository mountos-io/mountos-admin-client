import{a as r}from"../chunks/CFKNcHpF.js";import{x as t}from"../chunks/TYFGUR3K.js";export{t as load_css,r as start};
