import{a as r}from"../chunks/qbslattf.js";import{x as t}from"../chunks/Ceamdnia.js";export{t as load_css,r as start};
