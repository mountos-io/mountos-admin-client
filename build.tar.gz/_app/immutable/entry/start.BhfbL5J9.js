import{l as o,a as r}from"../chunks/BoKDP1jh.js";export{o as load_css,r as start};
