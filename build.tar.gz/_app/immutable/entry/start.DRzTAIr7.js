import{a as r}from"../chunks/DaOXNcqx.js";import{x as t}from"../chunks/DXAyTuaW.js";export{t as load_css,r as start};
