import{l as o,a as r}from"../chunks/BKru2yo8.js";export{o as load_css,r as start};
