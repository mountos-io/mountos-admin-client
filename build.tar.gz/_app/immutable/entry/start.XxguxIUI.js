import{l as o,a as r}from"../chunks/BHYYE2Nt.js";export{o as load_css,r as start};
