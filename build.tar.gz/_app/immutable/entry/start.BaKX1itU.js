import{a as r}from"../chunks/DZ3wDJIk.js";import{x as t}from"../chunks/wjs5gg3V.js";export{t as load_css,r as start};
