import{a as r}from"../chunks/B9C39ezd.js";import{x as t}from"../chunks/Cd4jPPmG.js";export{t as load_css,r as start};
