import{l as o,a as r}from"../chunks/cxU5ywsS.js";export{o as load_css,r as start};
