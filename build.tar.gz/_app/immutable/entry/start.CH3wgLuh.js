import{a as r}from"../chunks/ByOLtMMr.js";import{x as t}from"../chunks/ppFwjrZk.js";export{t as load_css,r as start};
