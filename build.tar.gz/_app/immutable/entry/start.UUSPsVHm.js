import{a as r}from"../chunks/Bt_lo4r9.js";import{x as t}from"../chunks/YyiYDG0K.js";export{t as load_css,r as start};
