import{a as r}from"../chunks/DxRi-rNm.js";import{x as t}from"../chunks/B5jUDpwM.js";export{t as load_css,r as start};
