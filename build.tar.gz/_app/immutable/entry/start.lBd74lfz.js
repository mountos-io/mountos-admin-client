import{l as o,a as r}from"../chunks/Ci43UlZi.js";export{o as load_css,r as start};
