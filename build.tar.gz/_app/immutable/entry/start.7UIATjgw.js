import{l as o,a as r}from"../chunks/qFp2R86s.js";export{o as load_css,r as start};
