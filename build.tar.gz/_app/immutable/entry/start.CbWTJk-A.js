import{a as r}from"../chunks/BP1J5NUF.js";import{x as t}from"../chunks/CR8T2R5O.js";export{t as load_css,r as start};
