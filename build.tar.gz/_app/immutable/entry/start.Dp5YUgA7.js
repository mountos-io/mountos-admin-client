import{a as r}from"../chunks/BbMRfmrz.js";import{x as t}from"../chunks/WGNfS7au.js";export{t as load_css,r as start};
