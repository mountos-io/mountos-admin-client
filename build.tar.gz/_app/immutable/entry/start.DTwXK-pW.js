import{a as r}from"../chunks/DQ1YW1HU.js";import{x as t}from"../chunks/lRz2rY3Q.js";export{t as load_css,r as start};
