import{a as r}from"../chunks/uFDtgtKI.js";import{x as t}from"../chunks/CBV9HHsM.js";export{t as load_css,r as start};
