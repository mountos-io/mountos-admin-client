import{l as o,a as r}from"../chunks/u-JIRne3.js";export{o as load_css,r as start};
