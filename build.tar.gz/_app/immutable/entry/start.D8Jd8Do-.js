import{l as o,a as r}from"../chunks/Dq_iDD99.js";export{o as load_css,r as start};
