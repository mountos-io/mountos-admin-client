import{a as r}from"../chunks/CVwglSbB.js";import{x as t}from"../chunks/CFrksP3i.js";export{t as load_css,r as start};
