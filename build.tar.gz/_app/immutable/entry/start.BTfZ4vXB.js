import{a as r}from"../chunks/epizupNf.js";import{x as t}from"../chunks/CFK23qjM.js";export{t as load_css,r as start};
