import{a as r}from"../chunks/HkCi7BYH.js";import{x as t}from"../chunks/BvLbgV71.js";export{t as load_css,r as start};
