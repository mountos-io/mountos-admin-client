import{l as o,a as r}from"../chunks/BKB6tQiW.js";export{o as load_css,r as start};
