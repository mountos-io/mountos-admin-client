import{a as r}from"../chunks/CGi3ohjy.js";import{x as t}from"../chunks/LvKtkEDI.js";export{t as load_css,r as start};
