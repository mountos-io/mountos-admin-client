import{l as o,a as r}from"../chunks/CL7PHXGz.js";export{o as load_css,r as start};
