import{a as r}from"../chunks/DZ5SqSil.js";import{x as t}from"../chunks/DIfBUl5S.js";export{t as load_css,r as start};
