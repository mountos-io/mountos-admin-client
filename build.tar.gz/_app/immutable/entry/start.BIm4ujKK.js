import{l as o,a as r}from"../chunks/CjWa0B08.js";export{o as load_css,r as start};
