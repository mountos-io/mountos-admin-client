import{a as r}from"../chunks/BhJmVnqn.js";import{x as t}from"../chunks/BGFz-qXo.js";export{t as load_css,r as start};
