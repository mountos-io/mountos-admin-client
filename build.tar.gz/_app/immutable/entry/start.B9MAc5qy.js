import{a as r}from"../chunks/wpYf27u-.js";import{x as t}from"../chunks/BIGtPxHf.js";export{t as load_css,r as start};
