import{a as r}from"../chunks/wrG882Nr.js";import{x as t}from"../chunks/B86oylLI.js";export{t as load_css,r as start};
