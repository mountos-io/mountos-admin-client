import{a as r}from"../chunks/DKFcYsbX.js";import{x as t}from"../chunks/AHqFZmlk.js";export{t as load_css,r as start};
