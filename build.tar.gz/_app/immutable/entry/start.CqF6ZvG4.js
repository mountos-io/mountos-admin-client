import{a as r}from"../chunks/C3QxfUFx.js";import{x as t}from"../chunks/BEqy59XU.js";export{t as load_css,r as start};
