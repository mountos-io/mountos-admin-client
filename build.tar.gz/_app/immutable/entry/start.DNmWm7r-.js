import{a as r}from"../chunks/DQEuIYEy.js";import{x as t}from"../chunks/DtN1nw5t.js";export{t as load_css,r as start};
