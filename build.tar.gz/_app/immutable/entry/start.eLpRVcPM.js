import{a as r}from"../chunks/DNuk-GKc.js";import{x as t}from"../chunks/Czx9sooc.js";export{t as load_css,r as start};
