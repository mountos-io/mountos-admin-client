import{l as o,a as r}from"../chunks/DYLWUVNm.js";export{o as load_css,r as start};
