import{a as r}from"../chunks/B7PaO5jp.js";import{x as t}from"../chunks/De5c9Cbk.js";export{t as load_css,r as start};
