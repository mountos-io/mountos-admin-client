import{af as a}from"./CyunQWKM.js";a();
