import{af as a}from"./Dg6oOoD6.js";a();
