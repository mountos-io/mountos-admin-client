import{ac as a}from"./fbpT_Qwa.js";a();
