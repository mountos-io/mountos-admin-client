const i={superadmin:"superadmin",l1admin:"l1admin",l2admin:"l2admin",user:"user"},n=s=>s!==i.user;export{i as R,n as i};
